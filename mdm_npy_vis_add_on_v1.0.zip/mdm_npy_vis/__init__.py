bl_info = {
    "name": "SMPL .npy Animation Importer",
    "author": "AI Assistant & You",
    "version": (1, 0, 2), # Update version number
    "blender": (2, 80, 0), # Minimum Blender version requirement
    "location": "View3D > Sidebar (N Panel) > SMPL Import Tab",
    "description": "Imports SMPL animation from .npy file and applies coordinate correction.",
    "warning": "",
    "doc_url": "", # You can add documentation link here
    "category": "Import-Export",
}

import bpy
import numpy as np
import math

# This is our previously improved core function, slightly modified to receive rotation parameters from the plugin UI
def import_smpl_animation_core(context, npy_file_path, rot_x_deg, rot_y_deg, rot_z_deg):
    """
    Core function: Creates mesh animation from .npy file and applies specified initial rotation.
    """
    print(f"Attempting to load .npy file from path: {npy_file_path}")
    try:
        data = np.load(npy_file_path, allow_pickle=True).item()
        print(".npy file loaded successfully.")
    except FileNotFoundError:
        print(f"Error: .npy file not found at path {npy_file_path}.")
        bpy.ops.wm.popup_dialog(title="Error", message=f"File not found: {npy_file_path}")
        return {'CANCELLED'}
    except Exception as e:
        print(f"Error: Failed to load .npy file: {e}")
        bpy.ops.wm.popup_dialog(title="Error", message=f"Failed to load .npy file: {e}")
        return {'CANCELLED'}

    required_keys = ['vertices', 'faces', 'length']
    if not all(key in data for key in required_keys):
        missing_keys = [key for key in required_keys if key not in data]
        message = f".npy file missing required keys: {missing_keys}"
        print(f"Error: {message}")
        bpy.ops.wm.popup_dialog(title="Error", message=message)
        return {'CANCELLED'}

    vertices_all_frames = data['vertices']
    faces = np.array(data['faces'])
    num_frames = int(data['length'])

    print(f"  Original frame count in file ('length'): {num_frames}")
    print(f"  Original shape of loaded vertices array: {vertices_all_frames.shape}")
    print(f"  Shape of loaded faces array: {faces.shape}")

    if num_frames <= 0:
        message = "Frame count ('length') must be greater than 0."
        print(f"Error: {message}")
        bpy.ops.wm.popup_dialog(title="Error", message=message)
        return {'CANCELLED'}

    # --- Validate and adjust vertex data shape ---
    expected_shape_pattern = f"({num_frames}, vertex_count, 3)"
    original_shape_for_error_msg = vertices_all_frames.shape # Save original shape for error messages

    if vertices_all_frames.ndim == 3 and \
       vertices_all_frames.shape[0] == num_frames and \
       vertices_all_frames.shape[2] == 3:
        print(f"Vertex data shape {vertices_all_frames.shape} matches expected {expected_shape_pattern}.")

    elif vertices_all_frames.ndim == 3 and \
         vertices_all_frames.shape[2] == num_frames and \
         vertices_all_frames.shape[1] == 3:
        detected_num_vertices = vertices_all_frames.shape[0]
        print(f"Warning: Vertex data shape is (vertex_count, 3, frames): {vertices_all_frames.shape}. Expected {expected_shape_pattern}.")
        print("Attempting to adjust it to (frames, vertex_count, 3)...")
        try:
            vertices_all_frames = vertices_all_frames.transpose(2, 0, 1) # (F, V, C)
            print(f"  Adjusted vertices array shape: {vertices_all_frames.shape}")
            if not (vertices_all_frames.shape[0] == num_frames and 
                    vertices_all_frames.shape[1] == detected_num_vertices and 
                    vertices_all_frames.shape[2] == 3):
                message = f"Transposed shape {vertices_all_frames.shape} still doesn't match expected ({num_frames}, {detected_num_vertices}, 3). Original shape: {original_shape_for_error_msg}"
                print(f"Error: {message}")
                bpy.ops.wm.popup_dialog(title="Error", message=message)
                return {'CANCELLED'}
        except Exception as e:
            message = f"Failed to transpose vertices array: {e}. Original shape: {original_shape_for_error_msg}"
            print(f"Error: {message}")
            bpy.ops.wm.popup_dialog(title="Error", message=message)
            return {'CANCELLED'}

    elif vertices_all_frames.ndim == 2 and \
         vertices_all_frames.shape[0] == num_frames and \
         vertices_all_frames.shape[1] % 3 == 0:
        num_vertices_in_frame = vertices_all_frames.shape[1] // 3
        print(f"Warning: Vertex data shape is (frames, vertex_count*3): {vertices_all_frames.shape}. Expected {expected_shape_pattern}.")
        print(f"Attempting to reshape it to ({num_frames}, {num_vertices_in_frame}, 3)...")
        try:
            vertices_all_frames = vertices_all_frames.reshape((num_frames, num_vertices_in_frame, 3))
            print(f"  Adjusted vertices array shape: {vertices_all_frames.shape}")
        except Exception as e:
            message = f"Failed to reshape vertices array: {e}. Original shape: {original_shape_for_error_msg}"
            print(f"Error: {message}")
            bpy.ops.wm.popup_dialog(title="Error", message=message)
            return {'CANCELLED'}
    else:
        message = f"Vertex data shape {vertices_all_frames.shape} is unrecognized or cannot be processed. Expected {expected_shape_pattern} or convertible variants. Original shape: {original_shape_for_error_msg}"
        print(f"Error: {message}")
        bpy.ops.wm.popup_dialog(title="Error", message=message)
        return {'CANCELLED'}

    if not (faces.ndim == 2 and faces.shape[1] >= 3):
        message = f"Invalid face data shape. Expected (face_count, >=3), got {faces.shape}"
        print(f"Error: {message}")
        bpy.ops.wm.popup_dialog(title="Error", message=message)
        return {'CANCELLED'}

    # --- Blender specific operations ---
    bpy.ops.object.select_all(action='DESELECT')
    object_name_prefix = "SMPL_Animated_Mesh"
    for obj_item in bpy.data.objects:
        if obj_item.type == 'MESH' and obj_item.name.startswith(object_name_prefix):
            bpy.data.objects.remove(obj_item, do_unlink=True)
    for mesh_item in bpy.data.meshes:
        if not mesh_item.users and mesh_item.name.startswith("SMPL_Mesh_Data"):
            bpy.data.meshes.remove(mesh_item)
    print(f"Old '{object_name_prefix}*' objects in scene have been cleaned up.")

    mesh_name = "SMPL_Mesh_Data"
    object_name = f"{object_name_prefix}_001"
    mesh_data = bpy.data.meshes.new(mesh_name)
    obj = bpy.data.objects.new(object_name, mesh_data)
    bpy.context.collection.objects.link(obj)
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)

    verts_frame0 = [tuple(v) for v in vertices_all_frames[0]]
    faces_list = [tuple(f) for f in faces]
    try:
        mesh_data.from_pydata(verts_frame0, [], faces_list)
    except Exception as e:
        message = f"Failed to create mesh with from_pydata: {e}\nPlease check vertex indices in face data or data format."
        print(f"Error: {message}")
        bpy.ops.wm.popup_dialog(title="Mesh Creation Error", message=message)
        bpy.data.objects.remove(obj, do_unlink=True)
        if mesh_data.users == 0: bpy.data.meshes.remove(mesh_data)
        return {'CANCELLED'}
    mesh_data.update()
    print(f"Mesh '{object_name}' created with geometry data from frame 0.")

    sk_basis = obj.shape_key_add(name='Basis')
    sk_basis.value = 1.0
    print("'Basis' shape key (corresponding to frame 0) created.")
    shape_key_list = [sk_basis]
    if num_frames > 1:
        for i in range(1, num_frames):
            key_name = f"Frame_{i:04d}"
            new_sk = obj.shape_key_add(name=key_name)
            try:
                for v_idx, v_coord in enumerate(vertices_all_frames[i]):
                    new_sk.data[v_idx].co = tuple(v_coord)
            except IndexError:
                message = f"Index error occurred when setting vertices for shape key '{key_name}' (original frame {i}).\nThis likely means vertex count doesn't match the base mesh."
                print(f"Error: {message}")
                bpy.ops.wm.popup_dialog(title="Shape Key Error", message=message)
                return {'CANCELLED'} # Or handle more gracefully
            shape_key_list.append(new_sk)
            if i % 50 == 0 or i == num_frames - 1 : print(f"'{key_name}' shape key (corresponding to frame {i}) created.")
        print("All shape keys created.")

    print("Setting animation values for shape keys...")
    for frame_num_on_timeline in range(num_frames):
        context.scene.frame_set(frame_num_on_timeline) # Using passed context
        for sk_idx, sk in enumerate(shape_key_list):
            sk.value = 1.0 if sk_idx == frame_num_on_timeline else 0.0
            sk.keyframe_insert(data_path='value', frame=frame_num_on_timeline)
        if frame_num_on_timeline % 50 == 0 or frame_num_on_timeline == num_frames - 1 :
             print(f"  Keyframes inserted for frame {frame_num_on_timeline} on Blender timeline.")

    context.scene.frame_start = 0
    context.scene.frame_end = num_frames - 1
    context.scene.frame_current = 0

    # Apply rotation parameters from UI
    obj.rotation_euler[0] = math.radians(rot_x_deg)
    obj.rotation_euler[1] = math.radians(rot_y_deg)
    obj.rotation_euler[2] = math.radians(rot_z_deg)
    print(f"  Initial rotation applied to object '{obj.name}': X={rot_x_deg}° Y={rot_y_deg}° Z={rot_z_deg}°.")
    print("Animation setup complete.")
    return {'FINISHED'}

# Define an operator - executed when user clicks the button
class SMPL_OT_ImportNPYAnimation(bpy.types.Operator):
    """Import SMPL .npy animation file and create animation"""
    bl_idname = "smpl.import_npy_animation" # Unique ID for the operator
    bl_label = "Import SMPL .npy Animation" # Label shown on button
    bl_options = {'REGISTER', 'UNDO'} # Enable undo functionality

    # File path property, Blender will automatically create a file selector for it
    filepath: bpy.props.StringProperty(
        name="File Path",
        description="Path to the .npy animation file",
        subtype='FILE_PATH', # This tells Blender to show a file selector
    )

    # Coordinate system correction rotation parameters (these appear in the F9 "Redo Last Operator" panel)
    rotation_x_degrees: bpy.props.FloatProperty(
        name="Rotate X (°)",
        description="Rotation around X-axis for coordinate correction",
        default=90.0, # Default X-axis rotation for Y-up to Z-up conversion
    )
    rotation_y_degrees: bpy.props.FloatProperty(
        name="Rotate Y (°)",
        description="Rotation around Y-axis for coordinate correction",
        default=0.0,
    )
    rotation_z_degrees: bpy.props.FloatProperty(
        name="Rotate Z (°)",
        description="Rotation around Z-axis for coordinate correction (e.g., 180 if facing wrong way)",
        default=0.0, # If standing up but facing wrong way, change to 180
    )

    def execute(self, context):
        if not self.filepath:
            self.report({'WARNING'}, "No file path specified.")
            return {'CANCELLED'}

        result = import_smpl_animation_core(
            context, # Pass context to core function
            self.filepath,
            self.rotation_x_degrees,
            self.rotation_y_degrees,
            self.rotation_z_degrees
        )
        if result == {'FINISHED'}:
            self.report({'INFO'}, f"Successfully imported SMPL animation from {self.filepath}.")
        else:
            self.report({'ERROR'}, f"Failed to import SMPL animation from {self.filepath}. See system console for details.")
        return result

    # Executed first when the operator is called (optional, but useful for file selectors)
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self) # Open file selection dialog
        return {'RUNNING_MODAL'} # Tell Blender the operator is running, waiting for file selection

# Define a panel - to display the button in Blender interface
class SMPL_PT_AnimationPanel(bpy.types.Panel):
    """Creates a custom panel in the 3D view sidebar (N key)"""
    bl_label = "SMPL .npy Importer" # Panel title
    bl_idname = "SMPL_PT_animation_import_panel" # Unique panel ID
    bl_space_type = 'VIEW_3D' # Panel appears in 3D view
    bl_region_type = 'UI' # Panel appears in UI region (typically sidebar)
    bl_category = 'SMPL Import' # Tab name in sidebar

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)

        # Add a button, clicking it will execute the SMPL_OT_ImportNPYAnimation operator above
        col.operator(SMPL_OT_ImportNPYAnimation.bl_idname, text="Import .npy Animation")

        # Note: The operator rotation parameters (rotation_x_degrees etc.)
        # will appear in the floating "Redo Last Operator" panel at the bottom left
        # (or by pressing F9) after user selects a file and runs the operator,
        # where users can adjust them.

# List of classes needed for registering and unregistering the plugin
classes = (
    SMPL_OT_ImportNPYAnimation,
    SMPL_PT_AnimationPanel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    print("SMPL .npy Animation Importer Add-on registered.")

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    print("SMPL .npy Animation Importer Add-on unregistered.")

# This allows the script to be run directly in Blender's text editor for testing (mainly for development)
if __name__ == "__main__":
    # When running in text editor, first try to unregister old version (if it exists)
    try:
        unregister()
    except RuntimeError: # If not previously registered, will raise RuntimeError
        pass
    register()

    # You can add a test call here, but usually the plugin is used via the UI
    # Example: bpy.ops.smpl.import_npy_animation('INVOKE_DEFAULT') 
    # 'INVOKE_DEFAULT' will trigger the invoke method, opening the file selector